$(function() {
	/*标记箭头是否已经点击 true 没有点击*/
	var flag = true;
	$(".arrow").click(function() {
		/*没有点击时*/
		if(flag == true) {
			/*下拉菜单向下滑动出现*/
			$(".dropdown").slideDown().css({
				"border": "1px solid #eb5a41",
				"border-top": "none",
				"border-bottom": "none",
				"background": "white"
			}).next().css("transform", "rotateZ(" + 180 + "deg) translateY(-" + 5 + "px)").parent().css({
				"border": "1px solid #eb5a41",
				"border-bottom": "none"
			});
			/*选择所在国家字体颜色变红*/
			$(".choose").css("color", "#eb5a41");
			flag = false;
		} else {
			$(".dropdown").slideUp().next().css("transform", "translateY(" + 0 + "px) rotateZ(" + 0 + "deg)").parent().css("border", "1px solid #e4e4e4");
			$(".choose").css("color", "#a3a3a5");
			flag = true;
		}
	});
	var t;
	/*下拉菜单hover时背景颜色改变 点击时颜色与hover颜色不同*/
	$(".dropdown>li").hover(function() {
		$(this).css("background", "#f4f4f4").siblings().css("background", "white");
	}).click(function() {
		$(this).addClass("grey");
		$(".con").html($(this).html()).next().slideUp().next().css("transform", "translateY(" + 0 + "px) rotateZ(" + 0 + "deg)").parent().css("border", "1px solid #e4e4e4");
		$(".choose").css("color", "#a3a3a5");
		flag = true;
		if($(this).index() > 0) {
			$(".num-holder").html("请输入邮箱");
			$(".isCorrect").hide();
			$(".message").hide();
			t = 0;
		} else {
			$(".num-holder").html("请输入手机号");
			$(".isCorrect").hide();
			$(".message").show();
			t = 1;
		}
	});

	$(".phone-wrap").click(function() {
		$(".num-holder").addClass("active-holder").animate({
			left: "16px",
			top: "-8px"
		}, 200);
		document.getElementById("num").focus();
		$(this).addClass("active-border");
	});

	$("#num").blur(function() {
		if(t == 0) {
			isMailNo();
		} else {
			isPhoneNo();
		}
		if($("#num").val() == "") {
			$(".num-holder").removeClass("active-holder").animate({
				left: "16px",
				top: "15px"
			}, 200).parent().removeClass("active-border");
		} 
	});
	var reg1 = /^1[3-9]\d{9}$/;
	var reg2 = /^([a-zA-Z0-9_-])+\@([a-zA-Z0-9_-])+.([a-zA-Z])+$/;

	function isPhoneNo() {
		if(reg1.test($("#num").val()) == false) {
			$(".isCorrect").show().html("请正确输入手机号");
		} else {
			$(".isCorrect").hide();
		}
	}

	function isMailNo() {
		if(reg2.test($("#num").val()) == false) {
			$(".isCorrect").show().html("请正确输入 邮箱地址");
		} else {
			$(".isCorrect").hide();
		}
	}
	$(".msg-wrap").click(function() {
		$(".msg-holder").addClass("active-holder").animate({
			left: "16px",
			top: "-8px"
		}, 200);
		document.getElementById("msg").focus();
		$(this).addClass("active-border");
	});
	console.log($("#msg").val());
	$("#msg").blur(function() {
		if($("#msg").val() == "") {

			$(".msg-holder").removeClass("active-holder").animate({
				left: "16px",
				top: "15px"
			}, 200).parent().removeClass("active-border");
		}
	});
	$(".pwd-wrap").click(function() {
		$(".pwd-holder").addClass("active-holder").animate({
			left: "16px",
			top: "-8px"
		}, 200);
		document.getElementById("pwd").focus();
		$(this).addClass("active-border");
	});
	$("#pwd").change(function() {
		if($("#pwd").val() == "") {
			$(".pwd-holder").removeClass("active-holder").animate({
				left: "16px",
				top: "15px"
			}, 200).parent().removeClass("active-border");
		}else{
			isPwdNo();
		}
		
	});
	var reg3 = /^(?![\d]+$)(?![a-zA-Z]+$)(?![^\da-zA-Z]+$).{6,20}$/;
	function isPwdNo() {
		if($("#pwd").val().length<=6){
			$(".isLong").show();
		}else{
			$(".isLong").hide();
			if(reg3.test($("#pwd").val()) == false){
			$(".isLong").hide();
			$(".isPwd").show();
			setTimeout(function() {
				$(".isPwd").hide();
			}, 3000);
		}else {
			$(".isPwd").hide();
		}
		} 
	}
	$(".confirm").click(function() {
		$.ajax({
			type: "post",
			url: "http://localhost:8080/user/sendCode",
			async: true,
			data: {
				"phone": $("#num").val()
			}
		});
	});
	$("#reg").submit(function() {
		isPwdNo();
		if(t == 0) {
			isMailNo();
		} else {
			isPhoneNo();
		}
		
		$.ajax({
			type: "post",
			url: "http://localhost:8080/user/register",
			async: true,
			data: {
				name: $("#num").val(),
				code: $("#msg").val(),
				"password": $("#pwd").val()
			}

		});
		return false;
	});
});